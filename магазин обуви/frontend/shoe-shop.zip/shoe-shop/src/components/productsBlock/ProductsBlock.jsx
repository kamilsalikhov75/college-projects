import { ProductCard } from '../productCard/ProductCard';
import './ProductsBlock.css';

function ProductsBlock({ title, products, likeProducts, setLikeProducts }) {
  return (
    <article className="products">
      <h3 className="title">{products.length ? title : 'Здесь пусто'}</h3>
      {products ? (
        <div className="products__block">
          {products.map((product) => {
            return (
              <ProductCard
                key={product._id}
                id={product._id}
                img={product.imageUrl}
                brand={product.brand}
                category={product.category}
                model={product.model}
                price={product.price}
                likeProducts={likeProducts}
                setLikeProducts={setLikeProducts}
              />
            );
          })}
        </div>
      ) : null}
    </article>
  );
}

export { ProductsBlock };
