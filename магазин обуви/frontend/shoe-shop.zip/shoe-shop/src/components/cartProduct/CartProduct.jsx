import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { saveCart } from '../../localStorage';
import './CartProduct.css';

function CartProduct({ cartProducts, setCartProducts, product, size, count }) {
  const [message, setMessage] = useState(false);

  function addProduct() {
    const productSize = product.sizes.find((item) => item.size === size);
    if (count < productSize.count) {
      const updatedCartProducts = cartProducts.map((cartProduct) => {
        if (cartProduct.id === product._id && cartProduct.size === size) {
          const newCount = cartProduct.count + 1;
          return { ...cartProduct, count: cartProduct.count + 1 };
        } else {
          return cartProduct;
        }
      });
      setCartProducts(updatedCartProducts);
      saveCart(updatedCartProducts);
    } else {
      setMessage('Товара нет в таком количестве');
      setTimeout(() => {
        setMessage(false);
      }, 1000);
    }
  }

  function reduceProduct() {
    if (count > 1) {
      const updatedCartProducts = cartProducts.map((cartProduct) => {
        if (cartProduct.id === product._id && cartProduct.size === size) {
          return { ...cartProduct, count: cartProduct.count - 1 };
        } else {
          return cartProduct;
        }
      });
      setCartProducts(updatedCartProducts);
      saveCart(updatedCartProducts);
    } else if (count === 1) {
      const updatedCartProducts = cartProducts.filter((cartProduct) => {
        if (cartProduct.id === product._id && cartProduct.size === size) {
          return false;
        }
        return true;
      });
      setCartProducts(updatedCartProducts);
      saveCart(updatedCartProducts);
    }
  }

  return (
    <div className="cart__product">
      <img
        src={`https://shoe-back.onrender.com${product.imageUrl}`}
        className="cart__product-img"
      />
      <div className="cart__product-text">
        <Link to={`/product/${product.id}`} className="cart__product-title">
          {product.brand}
        </Link>
        <p className="cart__product-desc">{`${product.category} ${product.model}`}</p>
      </div>
      <p className="cart__product-price">{product.price * count} ₽</p>
      <div className="cart__product-block">
        <p className="cart__product-size">{size}</p>
        <div className="cart__product-counter">
          <button onClick={reduceProduct} className="cart__product-button">
            <svg
              width="20"
              height="2"
              viewBox="0 0 20 2"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path d="M0 1H20" stroke="black" />
            </svg>
          </button>
          <p className="cart__product-count">{count}</p>
          <button onClick={addProduct} className="cart__product-button">
            <svg
              width="20"
              height="20"
              viewBox="0 0 20 20"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path d="M0 10H20M10 20V0" stroke="black" />
            </svg>
          </button>
          {message ? <p className="cart__message">{message}</p> : null}
        </div>
      </div>
    </div>
  );
}

export { CartProduct };
