export function saveCart(cartProducts) {
  try {
    localStorage.setItem('cart', JSON.stringify(cartProducts));
  } catch (error) {
    console.log(error);
  }
}
export function saveLikes(likeProducts) {
  try {
    localStorage.setItem('likes', JSON.stringify(likeProducts));
  } catch (error) {
    console.log(error);
  }
}

export function getCart() {
  try {
    const cartProducts = JSON.parse(localStorage.getItem('cart'));
    if (cartProducts) {
      return cartProducts;
    }
    return [];
  } catch (error) {
    console.log(error);
  }
}

export function getLikes() {
  try {
    const likeProducts = JSON.parse(localStorage.getItem('likes'));
    if (likeProducts) {
      return likeProducts;
    }
    return [];
  } catch (error) {
    console.log(error);
  }
}

export function getToken() {
  try {
    const token = localStorage.getItem('token');
    if (token) {
      return token;
    }
    return '';
  } catch (error) {
    console.log(error);
  }
}
