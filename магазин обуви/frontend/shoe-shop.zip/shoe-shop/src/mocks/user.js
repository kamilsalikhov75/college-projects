const user = {
  id: 1,
  login: 'ivan',
  password: 'ivan123',
  firstName: 'Иван',
  lastName: 'Иванов',
  likes: [1, 3, 5, 7, 10],
};

export { user };
