import { useEffect, useState } from 'react';
import { Categories } from '../../components/categories/Categories';
import { ProductsBlock } from '../../components/productsBlock/ProductsBlock';
import { fetchProducts } from '../../fetch';
// import { products } from '../../mocks/product';

function Main({ likeProducts, setLikeProducts }) {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    const promise = fetchProducts();
    promise.then((responce) => setProducts(responce));
  }, []);

  return (
    <>
      <Categories />
      <ProductsBlock
        title="Новые поступления"
        products={products.filter((product, index) => {
          if (products.length - index < 5) {
            return true;
          }
        })}
        likeProducts={likeProducts}
        setLikeProducts={setLikeProducts}
      />
    </>
  );
}

export { Main };
