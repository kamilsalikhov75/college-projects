import axios from 'axios';
import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { link } from '../../const';
import './login.css';

function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();

  async function login() {
    try {
      const user = {
        email,
        password,
      };
      const responce = await axios.post(
        'https://shoe-back.onrender.com/auth/login',
        user
      );
      if (responce.status === 200) {
        localStorage.setItem('token', responce.data.token);
        navigate('/user')
      }
    } catch (error) {
      console.log(error);
    }
  }

  return (
    <div className="login">
      <form
        className="login__form"
        onSubmit={(e) => {
          e.preventDefault();
          login();
        }}
      >
        <input
          type="text"
          className="login__input"
          placeholder="Электронная почта"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
        <input
          type="text"
          className="login__input"
          placeholder="Пароль"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
        <button className="button">Войти</button>
      </form>
      <div className="login__block">
        <p className="login__text">Если еще не зарегистрированы:</p>
        <Link to={link.registration} className="login__link">
          Регистрация
        </Link>
      </div>
    </div>
  );
}

export { Login };
