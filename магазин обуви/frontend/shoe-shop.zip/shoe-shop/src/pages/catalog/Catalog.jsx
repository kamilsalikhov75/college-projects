import { useEffect, useState } from 'react';
import { Filter } from '../../components/filter/Filter';
import { ProductsBlock } from '../../components/productsBlock/ProductsBlock';
import { Sort } from '../../components/sort/Sort';
import { sort, defaultFilter } from '../../const';
import { fetchProducts } from '../../fetch';
import { products } from '../../mocks/product';
import './Catalog.css';

function Catalog({ gender, likeProducts, setLikeProducts }) {
  const [products, setProducts] = useState([]);
  const [filtredProducts, setFiltredProducts] = useState(products);
  const [title, setTitle] = useState(getTitle(gender));

  useEffect(() => {
    const promise = fetchProducts();
    promise.then((responce) => {
      setProducts(responce);
      setFiltredProducts(getDefaultProducts(gender, responce));
    });
    setTitle(getTitle(gender));
  }, [gender]);

  return (
    <>
      {/* <Sort setCurrentSort={setCurrentSort} />
      <Filter
        currentProducts={currentProducts}
        setBrandFilter={setBrandFilter}
        setSizeFilter={setSizeFilter}
        sizeFilter={sizeFilter}
        brandFilter={brandFilter}
      /> */}
      <ProductsBlock
        title={title}
        products={filtredProducts}
        likeProducts={likeProducts}
        setLikeProducts={setLikeProducts}
      />
    </>
  );
}

function getTitle(gender) {
  switch (gender) {
    case 'male':
      return 'Мужская обувь';
    case 'female':
      return 'Женская обувь';
    default:
      break;
  }
}

function getDefaultProducts(gender, products) {
  const filtredProducts = products.filter((product) => {
    if (product.gender === 'unisex' || product.gender === gender) {
      return true;
    }
  });
  return filtredProducts;
}
export { Catalog };
