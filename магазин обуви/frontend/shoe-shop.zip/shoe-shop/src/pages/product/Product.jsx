import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { SizeButton } from '../../components/sizeButton/SizeButton';
import { link } from '../../const';
import { fetchProduct } from '../../fetch';
import { saveCart } from '../../localStorage';
import { products } from '../../mocks/product';
import './Product.css';

const initialProduct = {
  _id: '',
  title: '',
  brand: '',
  imageUrl: '',
  category: '',
  price: '',
  sizes: [''],
  gender: '',
};

function Product({ cartProducts, setCartProducts }) {
  const { id } = useParams();
  const [product, setProduct] = useState(initialProduct);
  const [currentSize, setCurrentSize] = useState('');
  const isInCart = cartProducts.find((cartProduct) => {
    if (cartProduct.id === id && cartProduct.size === currentSize) {
      return true;
    }
  });
  const navigate = useNavigate();

  useEffect(() => {
    const promise = fetchProduct(id);
    promise.then((responce) => setProduct(responce));
  }, []);

  useEffect(() => {
    setCurrentSize(product.sizes[0].size);
  }, [product]);

  function addToCart() {
    if (isInCart) {
      navigate(link.cart);
    } else {
      const cartProduct = { id, size: currentSize, count: 1 };
      setCartProducts([...cartProducts, cartProduct]);
      saveCart([...cartProducts, cartProduct]);
    }
  }

  return (
    <div className="product__page-block">
      <img
        src={`https://shoe-back.onrender.com${product.imageUrl}`}
        alt=""
        className="product__page-img"
      />
      <div className="product__page-info">
        <h1 className="product__info-title">{product.brand}</h1>
        <p className="product__info-subtitle">{`${product.category} ${product.model}`}</p>
        <div className="product__sizes-block">
          <p className="product__sizes-title">Доступные размеры</p>
          <div className="sizes__buttons">
            {product.sizes.map((size) => {
              if (size.size === currentSize) {
                return (
                  <SizeButton
                    key={size.size}
                    size={size.size}
                    setCurrentSize={setCurrentSize}
                    className="size__button size__button--active"
                  />
                );
              }
              return (
                <SizeButton
                  key={size.size}
                  size={size.size}
                  setCurrentSize={setCurrentSize}
                  className="size__button"
                />
              );
            })}
          </div>
        </div>
        <p className="product__price">{product.price} ₽</p>
        <button onClick={addToCart} className="product__cart-button">
          {isInCart ? 'В корзине' : 'Добавить в корзину'}
        </button>
      </div>
    </div>
  );
}

export { Product };
