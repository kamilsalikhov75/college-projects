import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { CartProduct } from '../../components/cartProduct/CartProduct';
import { link } from '../../const';
import { fetchPostOrder, fetchProducts, fetchUser } from '../../fetch';
import { getToken, saveCart } from '../../localStorage';
import './cart.css';

const initialProduct = {
  _id: '',
  title: '',
  brand: '',
  imageUrl: '',
  category: '',
  price: '',
  sizes: [''],
  gender: '',
};

function Cart({ cartProducts, setCartProducts }) {
  const [products, setProducts] = useState('');

  const navigate = useNavigate();
  const [user, setUser] = useState('');

  useEffect(() => {
    const token = getToken();
    if (token) {
      fetchUser(token, setUser);
    } else {
      setUser('');
    }
  }, []);

  useEffect(() => {
    const promise = fetchProducts();
    promise.then((responce) => setProducts(responce));
  }, []);

  function createOrder() {
    if (!user) {
      navigate(link.login);
    } else {
      const price = getPrice();
      const orderProducts = cartProducts.map((cartProduct) => {
        const currentProduct = products.find(
          (item) => item._id === cartProduct.id
        );
        return {
          _id: cartProduct.id,
          ...cartProduct,
          model: currentProduct.model,
          brand: currentProduct.brand,
          category: currentProduct.category,
          price: currentProduct.price,
        };
      });
      const order = { products: orderProducts, price };
      const promise = fetchPostOrder(getToken(), order);
      promise.then((responce) => {
        if (responce.status === 200) {
          setCartProducts('');
          localStorage.removeItem('cart');
          navigate(link.user);
        }
      });
    }
  }

  function getPrice() {
    return cartProducts.reduce((sum, current) => {
      const currentProduct = products.find((item) => item._id === current.id);
      return sum + currentProduct.price * current.count;
    }, 0);
  }

  return (
    <div className="cart">
      {cartProducts.length && products ? (
        <>
          <h3 className="title">Корзина</h3>
          <div className="cart__products">
            {cartProducts.map((cartProduct) => (
              <CartProduct
                cartProducts={cartProducts}
                setCartProducts={setCartProducts}
                key={`${cartProduct.id}${cartProduct.size}`}
                product={products.find((item) => item._id === cartProduct.id)}
                size={cartProduct.size}
                count={cartProduct.count}
              />
            ))}
          </div>
          <div className="cart__info-block">
            <h3 className="cart__info-title">Доставка</h3>
            <p className="cart__info-text">
              Самовывоз из магазина по адресу Каретный ряд, 8. По готовности
              заказа вы получите SMS-уведомление. Срок хранения: 2 календарных
              дня.
            </p>
          </div>
          <div className="cart__info-block">
            <h3 className="cart__info-title">Оплата</h3>
            <p className="cart__info-text">
              При получении наличными или картой
            </p>
          </div>
          <div className="cart__block">
            <p className="cart__block-text">
              Итого <span>{getPrice()} ₽</span>
            </p>
            <button onClick={createOrder} className="button">
              Оформить заказ
            </button>
          </div>
        </>
      ) : (
        <h3 className="title">Корзина пуста</h3>
      )}
    </div>
  );
}

export { Cart };
