import axios from 'axios';
import { useEffect, useState } from 'react';
import { Navigate, useNavigate } from 'react-router-dom';
import { link } from '../../const';
import { fetchGetUserOrders, fetchUser } from '../../fetch';
import { getToken } from '../../localStorage';
import './user.css';

const status = {
  new: 'Новый',
  done: 'Выполнен',
};

const initialUser = {
  firstName: '',
  lastName: '',
  email: '',
  phone: '',
};

function User() {
  const navigate = useNavigate();
  const [user, setUser] = useState(initialUser);
  const [orders, setOrders] = useState();

  useEffect(() => {
    const token = getToken();
    if (token) {
      fetchUser(token, setUser);
      fetchGetUserOrders(token, setOrders);
    } else {
      navigate('/login');
    }
  }, []);

  function logout() {
    localStorage.removeItem('token');
    navigate('/index.html');
  }

  return (
    <div className="user">
      <div className="user__info-block">
        <h4 className="user__title">Имя</h4>
        <p className="user__info-text">{user.firstName}</p>
      </div>
      <div className="user__info-block">
        <h4 className="user__title">Фамилия</h4>
        <p className="user__info-text">{user.lastName}</p>
      </div>
      <div className="user__info-block">
        <h4 className="user__title">Электронная почта</h4>
        <p className="user__info-text">{user.email}</p>
      </div>
      <div className="user__info-block">
        <h4 className="user__title">Номер телефона</h4>
        <p className="user__info-text">{user.phone}</p>
      </div>
      <button onClick={logout} className="button">
        Выход
      </button>
      <div className="user__orders">
        <h4 className="user__title">Заказы</h4>
        <div className="user__orders__block">
          {orders
            ? orders.map((order, index) => (
                <div className="user__order" key={order._id}>
                  <div className="order__top">
                    <p className="order__text">Заказ №{index + 1}</p>
                    <p className="order__text">
                      Дата заказа {new Date(order.createdAt).toLocaleString()}
                    </p>
                    <p className="order__text">
                      Статус заказа {status[order.status]}
                    </p>
                  </div>
                  <div className="order__products">
                    <p className="order__title">Товары</p>
                    {order.products.map((product) => (
                      <div
                        className="order__product"
                        key={`${product._id}${product.size}`}
                      >
                        <p className="order__product-text">
                          Бренд {product.brand}
                        </p>
                        <p className="order__product-text">
                          Категория {product.catagory}
                        </p>
                        <p className="order__product-text">
                          Модель {product.model}
                        </p>
                        <p className="order__product-text">
                          Количество {product.count} шт.
                        </p>
                        <p className="order__product-text">
                          Цена {product.price} ₽
                        </p>
                      </div>
                    ))}
                  </div>
                  <p className="order__price">Сумма {order.price} ₽</p>
                </div>
              ))
            : null}
        </div>
      </div>
    </div>
  );
}

export { User };
