import { useEffect, useState } from 'react';
import { ProductsBlock } from '../../components/productsBlock/ProductsBlock';
import { fetchProducts } from '../../fetch';
import { products } from '../../mocks/product';
import { user } from '../../mocks/user';

function Likes({ likeProducts, setLikeProducts }) {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    const promise = fetchProducts();
    promise.then((responce) => setProducts(responce));
  }, []);
  return (
    <ProductsBlock
      title="Понравившиеся товары"
      products={products.filter((product) => likeProducts.includes(product._id))}
      likeProducts={likeProducts}
      setLikeProducts={setLikeProducts}
    />
  );
}

export { Likes };
