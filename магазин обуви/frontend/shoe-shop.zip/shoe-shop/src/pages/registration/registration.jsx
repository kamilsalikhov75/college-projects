import axios from 'axios';
import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { link } from '../../const';
import './registration.css';

function Registration() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [phone, setPhone] = useState('');
  const navigate = useNavigate();

  async function register() {
    try {
      const user = {
        email,
        password,
        firstName,
        lastName,
        phone,
      };
      const responce = await axios.post(
        'https://shoe-back.onrender.com/auth/register',
        user
      );
      if (responce.status === 200) {
        localStorage.setItem('token', responce.data.token);
        navigate("/user")
      }
    } catch (error) {
      console.log(error);
    }
  }

  return (
    <div className="login">
      <form
        className="login__form"
        onSubmit={(e) => {
          e.preventDefault();
          register();
        }}
      >
        <input
          type="text"
          className="login__input"
          placeholder="Имя"
          value={firstName}
          onChange={(e) => setFirstName(e.target.value)}
        />
        <input
          type="text"
          className="login__input"
          placeholder="Фамилия"
          value={lastName}
          onChange={(e) => setLastName(e.target.value)}
        />
        <input
          type="text"
          className="login__input"
          placeholder="Номер телефона"
          value={phone}
          onChange={(e) => setPhone(e.target.value)}
        />
        <input
          type="text"
          className="login__input"
          placeholder="Электронная почта"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
        <input
          type="text"
          className="login__input"
          placeholder="Пароль"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
        <button className="button">Зарегистрироваться</button>
      </form>
      <div className="login__block">
        <p className="login__text">Если уже зарегистрированы:</p>
        <Link to={link.login} className="login__link">
          Авторизация
        </Link>
      </div>
    </div>
  );
}

export { Registration };
