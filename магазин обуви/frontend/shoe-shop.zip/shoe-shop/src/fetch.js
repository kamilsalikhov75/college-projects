import axios from 'axios';

export async function fetchUser(token, setUser) {
  try {
    const responce = await axios.get('https://shoe-back.onrender.com/auth/user', {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
    if (responce.status === 200) {
      setUser(responce.data.userData);
    }
  } catch (error) {
    console.log(error);
  }
}

export async function fetchProducts() {
  try {
    const responce = await axios.get('https://shoe-back.onrender.com/products');
    return responce.data;
  } catch (error) {
    console.log(error);
  }
}

export async function fetchProduct(id) {
  try {
    const responce = await axios.get(`https://shoe-back.onrender.com/products/${id}`);
    return responce.data;
  } catch (error) {
    console.log(error);
  }
}
export async function fetchPostOrder(token, order) {
  try {
    const responce = await axios.post('https://shoe-back.onrender.com/orders', order, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
    return responce;
  } catch (error) {
    console.log(error);
  }
}

export async function fetchGetUserOrders(token, setOrders) {
  try {
    const responce = await axios.get('https://shoe-back.onrender.com/orders', {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
    setOrders(responce.data);
  } catch (error) {
    console.log(error);
  }
}
