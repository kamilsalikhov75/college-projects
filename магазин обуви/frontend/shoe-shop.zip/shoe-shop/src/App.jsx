import { useEffect, useState } from 'react';
import { Routes, Route } from 'react-router-dom';

import './App.css';
import { Footer } from './components/footer/Footer';
import { Header } from './components/header/Header';
import { link } from './const';
import { getCart, getLikes } from './localStorage';
import { Cart } from './pages/cart/cart';
import { Catalog } from './pages/catalog/Catalog';
import { Error } from './pages/error/Error';
import { Likes } from './pages/likes/Likes';
import { Login } from './pages/login/login';
import { Main } from './pages/main/Main';
import { Product } from './pages/product/Product';
import { Registration } from './pages/registration/registration';
import { User } from './pages/user/user';

function App() {
  const [cartProducts, setCartProducts] = useState(getCart());
  const [likeProducts, setLikeProducts] = useState(getLikes());

  return (
    <>
      <Header />
      <Routes>
        <Route
          path={link.home}
          element={
            <Main
              likeProducts={likeProducts}
              setLikeProducts={setLikeProducts}
            />
          }
        />
        <Route
          path={link.likes}
          element={
            <Likes
              likeProducts={likeProducts}
              setLikeProducts={setLikeProducts}
            />
          }
        />
        <Route
          path={link.male}
          element={
            <Catalog
              likeProducts={likeProducts}
              setLikeProducts={setLikeProducts}
              gender="male"
            />
          }
        />
        <Route
          path={link.female}
          element={
            <Catalog
              likeProducts={likeProducts}
              setLikeProducts={setLikeProducts}
              gender="female"
            />
          }
        />
        <Route
          path={link.product}
          element={
            <Product
              cartProducts={cartProducts}
              setCartProducts={setCartProducts}
            />
          }
        />
        <Route
          path={link.cart}
          element={
            <Cart
              cartProducts={cartProducts}
              setCartProducts={setCartProducts}
            />
          }
        />
        <Route path={link.user} element={<User />} />
        <Route path={link.login} element={<Login />} />
        <Route path={link.registration} element={<Registration />} />
        <Route path="*" element={<Error />} />
      </Routes>
      <Footer />
    </>
  );
}

export default App;
