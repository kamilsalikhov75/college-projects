import { Link } from 'react-router-dom';
import headerLogo from '../../assets/header-logo.svg';
import './header.css';

function Header() {
  return (
    <header className="header">
      <div className="container">
        <div className="header__top">
          <Link className="header__logo-link" to="/">
            <img src={headerLogo} className="header__logo" />
          </Link>
          <Link to="/cart" className="header__link">
            <svg
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <g clipPath="url(#clip0_506_2859)">
                <path
                  d="M8.57143 5.25C8.57143 3.59531 10.1089 2.25 12 2.25C13.8911 2.25 15.4286 3.59531 15.4286 5.25V7.5H8.57143V5.25ZM6 7.5H2.57143C1.15179 7.5 0 8.50781 0 9.75V19.5C0 21.9844 2.30357 24 5.14286 24H18.8571C21.6964 24 24 21.9844 24 19.5V9.75C24 8.50781 22.8482 7.5 21.4286 7.5H18V5.25C18 2.34844 15.3161 0 12 0C8.68393 0 6 2.34844 6 5.25V7.5ZM7.28571 12C6.57321 12 6 11.4984 6 10.875C6 10.2516 6.57321 9.75 7.28571 9.75C7.99821 9.75 8.57143 10.2516 8.57143 10.875C8.57143 11.4984 7.99821 12 7.28571 12ZM18 10.875C18 11.4984 17.4268 12 16.7143 12C16.0018 12 15.4286 11.4984 15.4286 10.875C15.4286 10.2516 16.0018 9.75 16.7143 9.75C17.4268 9.75 18 10.2516 18 10.875Z"
                  fill="#7AC5C2"
                />
              </g>
              <defs>
                <clipPath id="clip0_506_2859">
                  <rect width="24" height="24" fill="white" />
                </clipPath>
              </defs>
            </svg>
          </Link>
        </div>
        <nav className="header__navigation">
          <Link to="/catalog" className="header__navigation-link">
            КАТАЛОГ
          </Link>
          <Link to="/bikes" className="header__navigation-link">
            Велосипеды
          </Link>
          <Link to="/accessories" className="header__navigation-link">
            Аксессуары для велосипедов
          </Link>
          <Link to="/wear" className="header__navigation-link">
            Одежда
          </Link>
          <Link to="/about" className="header__navigation-link">
            О магазине
          </Link>
        </nav>
      </div>
    </header>
  );
}

export{Header}
