import { Link } from 'react-router-dom';
import footerLogo from '../../assets/footer-logo.svg';
import './product-card.css';

function ProductCard({ id, category, name, price, img }) {
  return (
    <div className="product__card">
      <Link to={`product/${id}`} className="product__card-link">
        <img src={img} className="product__card-img" />
      </Link>
      <h5 className="product__card-title">{name}</h5>
      <div className="product__card-bottom">
        <Link to={category.path} className="product__card-category-link">
          {category.name}
        </Link>
        <p className="product__card-price">{price} ₽</p>
      </div>
      <button className="product__card-button">В корзину</button>
    </div>
  );
}

export { ProductCard };
