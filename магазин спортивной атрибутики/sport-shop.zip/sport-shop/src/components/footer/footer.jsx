import { Link } from 'react-router-dom';
import footerLogo from '../../assets/footer-logo.svg';
import './footer.css';

function Footer() {
  return (
    <footer className="footer">
      <div className="container footer__container">
        <Link to="/" className="footer__link">
          <img src={footerLogo} className="footer__image" />
        </Link>
      </div>
    </footer>
  );
}

export { Footer };
