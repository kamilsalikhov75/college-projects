import { Link } from 'react-router-dom';
import './category-card.css';

function CategoryCard({path, img, text}) {
  return (
    <Link to={path} className="category__card">
      <img src={img} className="category__image" />
      <p className="category__text">{text}</p>
    </Link>
  );
}

export { CategoryCard };
