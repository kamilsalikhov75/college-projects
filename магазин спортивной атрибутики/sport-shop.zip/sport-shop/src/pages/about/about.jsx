import './about.css';

function About({ id, category, name, price, img }) {
  return (
    <div className="about">
      <div className="container">
        <h1 className="about__title">О магазине</h1>
        <div className="about__block">
          <p className="about__text">
            Вы находитесь в интернет магазине спортивных товаров. У нас нет
            локальных магазинов, но вы всегда можете заказать нужные вам товары
            и наш менеджер свяжется с вами для уточнения заказа. Если у вас
            возникнут вопросы менеджер с радостью ответит на них.
          </p>
          <a href="tel:+89148374536" className="about__link">
            Позвонить нам (89148374536)
          </a>
        </div>
      </div>
    </div>
  );
}

export { About };
