import { Link } from 'react-router-dom';
import { CategoryCard } from '../../components/category-card/category-card';
import './main.css';
import bikesImage from '/bikes.jpg';
import accessoriesImage from '/accessories.jpg';
import wearImage from '/wear.jpg';
function Main() {
  return (
    <div className="main">
      <div className="container main__container">
        <CategoryCard path="/bikes" img={bikesImage} text="Велосипеды" />
        <CategoryCard
          path="/accessories"
          img={accessoriesImage}
          text="Аксессуары"
        />
        <CategoryCard path="/wear" img={wearImage} text="Одежда" />
      </div>
    </div>
  );
}

export { Main };
