import { ProductCard } from '../../components/product-card/product-card';
import './products.css';

function Products({ categoryFilter }) {
  const products = [
    {
      name: 'Велосипед тестовый',
      img: '/bike.jpg',
      id: 1,
      category: {
        name: 'Велосипеды',
        path: '/bikes',
      },
      price: 59000,
    },
    {
      name: 'Аксессуар тестовый',
      img: '/bike.jpg',
      id: 2,
      category: {
        name: 'Аксессуары',
        path: '/accessories',
      },
      price: 1000,
    },
    {
      name: 'Одежда тестовая',
      img: '/bike.jpg',
      id: 3,
      category: {
        name: 'Одежда',
        path: '/wear',
      },
      price: 3000,
    },
  ];

  const filtredProducts = categoryFilter
    ? products.filter((product) => product.category.name === categoryFilter)
    : products;
  return (
    <div className="products">
      <div className="container products__container">
        {filtredProducts
          ? filtredProducts.map((product) => (
              <ProductCard
                key={product.id}
                id={product.id}
                category={product.category}
                name={product.name}
                price={product.price}
                img={product.img}
              />
            ))
          : 'Товаро нет'}
      </div>
    </div>
  );
}

export { Products };
