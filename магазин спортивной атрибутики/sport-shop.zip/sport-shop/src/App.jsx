import { useState } from 'react';
import reactLogo from './assets/react.svg';
import './App.css';
import { Header } from './components/header/header';
import { Route, Routes } from 'react-router-dom';
import { Main } from './pages/main/main';
import { Footer } from './components/footer/footer';
import { Products } from './pages/products/products';
import { About } from './pages/about/about';

function App() {
  return (
    <>
      <Header />
      <Routes>
        <Route path="/" element={<Main />} />
        <Route path="/catalog" element={<Products />} />
        <Route
          path="/bikes"
          element={<Products categoryFilter="Велосипеды" />}
        />
        <Route
          path="/accessories"
          element={<Products categoryFilter="Аксессуары" />}
        />
        <Route path="/wear" element={<Products categoryFilter="Одежда" />} />
        <Route path="/about" element={<About />} />
      </Routes>
      <Footer />
    </>
  );
}

export default App;
