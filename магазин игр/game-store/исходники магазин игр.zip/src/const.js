export const api = 'https://gamer-back.onrender.com';

export const categories = {
  ps5: 'Игры для PlayStation 5',
  ps4: 'Игры для PlayStation 4',
  xbox: 'Игры для Xbox',
  switch: 'Игры для Nintendo Switch',
  pc: 'Игры для ПК',
  tablegames: 'Настольные игры',
  comics: 'Комиксы',
};
